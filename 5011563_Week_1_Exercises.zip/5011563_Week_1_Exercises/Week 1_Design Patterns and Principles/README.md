### Name : Arka Pratim Ghosh
### SuperSet ID : 5011563
### Email : arkapratimghosh1264@gmail.com
### GitHub Repository : https://github.com/arkapg211002/5011563

### Week 1 : Design Patterns and Principles